"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mod = void 0;
const PrefixLogger_1 = require("./util/PrefixLogger");
const ConfigServer_1 = require("./servers/ConfigServer");
const SecureContainerOptionsChanger_1 = require("./changers/SecureContainerOptionsChanger");
const HideoutOptionsChanger_1 = require("./changers/HideoutOptionsChanger");
const EconomyOptionsChanger_1 = require("./changers/EconomyOptionsChanger");
const TraderChangesChanger_1 = require("./changers/TraderChangesChanger");
const CraftingChangesChanger_1 = require("./changers/CraftingChangesChanger");
const InsuranceChangesChanger_1 = require("./changers/InsuranceChangesChanger");
const OtherTweaksChanger_1 = require("./changers/OtherTweaksChanger");
class Softcore {
    logger = null;
    config = null;
    preSptLoad(container) {
        try {
            this.logger = PrefixLogger_1.PrefixLogger.getInstance(container);
        }
        catch (error) {
            const logger = container.resolve("WinstonLogger");
            logger.error("[Softcore]: ${error.message}, stopping mod");
            return;
        }
        try {
            this.config = new ConfigServer_1.ConfigServer().loadConfig().getConfig();
        }
        catch (error) {
            this.config = null;
            this.logger.error("ConfigServer: ${error.message}");
        }
        // Can stop if config is either null or not initialized
        if (this.config == null) {
            return;
        }
        // Can stop if mod not enabled
        if (!this.config.general.enabled) {
            this.logger.info("Config: Mod disabled in the config file");
            this.config = null;
            return;
        }
    }
    postDBLoad(container) {
        // Only enters if config is invalid / not found or mod disabled. Logging for this happened in preSptLoad
        if (this.config === null || this.logger === null) {
            return;
        }
        this.logger.setDebug(this.config.general.debug);
        // Initialize all the changes and apply them according to the config
        new SecureContainerOptionsChanger_1.SecureContainerOptionsChanger(container).apply(this.config.secureContainersOptions);
        new HideoutOptionsChanger_1.HideoutOptionsChanger(container).apply(this.config.hideoutOptions);
        new EconomyOptionsChanger_1.EconomyOptionsChanger(container).apply(this.config.economyOptions);
        new TraderChangesChanger_1.TraderChangesChanger(container).apply(this.config.traderChanges);
        new CraftingChangesChanger_1.CraftingChangesChanger(container).apply(this.config.craftingChanges);
        new InsuranceChangesChanger_1.InsuranceChangesChanger(container).apply(this.config.insuranceChanges);
        new OtherTweaksChanger_1.OtherTweaksChanger(container).apply(this.config.otherTweaks);
        this.logger.info("Loaded Changes successfully");
    }
}
exports.mod = new Softcore();
//# sourceMappingURL=Softcore.js.map