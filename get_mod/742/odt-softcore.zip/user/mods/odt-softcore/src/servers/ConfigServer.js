"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigServer = void 0;
const fs = __importStar(require("node:fs"));
const json5 = __importStar(require("C:/snapshot/project/node_modules/json5"));
const node_path_1 = require("node:path");
/**
 * ConfigServer Class
 *
 * The ConfigServer class is responsible for managing the application's configuration settings.
 * It provides functionality to load a configuration file, which is specified in JSON5 format.
 */
class ConfigServer {
    relativeConfigPath;
    configPath;
    config = null;
    isLoaded = false;
    /**
     * Constructs a new ConfigServer instance.
     * Automatically loads the configuration file specified by the relative path.
     *
     * @param {string} relativeConfigPath - The relative path to the configuration file.
     */
    constructor(relativeConfigPath = "../../config/config.json5") {
        this.relativeConfigPath = relativeConfigPath;
        this.configPath = this.buildConfigPath();
    }
    /**
     * Constructs the absolute path to the configuration file based on its relative path.
     *
     * @returns {string} - The absolute path to the configuration file.
     */
    buildConfigPath() {
        return (0, node_path_1.join)(__dirname, this.relativeConfigPath);
    }
    /**
     * Loads the configuration from a file. Sets the `isLoaded` flag to true if successful, false otherwise.
     * Throws an error if the file cannot be loaded.
     *
     * @returns {this} - Returns the ConfigServer instance.
     */
    loadConfig() {
        try {
            const configFileContent = fs.readFileSync(this.configPath, "utf-8");
            this.config = json5.parse(configFileContent);
            this.isLoaded = true;
        }
        catch (error) {
            this.config = null;
            this.isLoaded = false;
            throw new Error("CONFIG_LOAD_ERROR - Could not load configuration");
        }
        return this;
    }
    /**
     * Retrieves the loaded configuration.
     *
     * @returns {Configuration | null} - The loaded configuration, or null if the configuration is not loaded.
     */
    getConfig() {
        if (!this.isLoaded) {
            throw new Error("CONFIG_NOT_LOADED - Configuration not loaded");
        }
        return this.config;
    }
}
exports.ConfigServer = ConfigServer;
//# sourceMappingURL=ConfigServer.js.map