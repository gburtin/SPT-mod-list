"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FasterCraftingTimeChanger = void 0;
const ItemTpl_1 = require("C:/snapshot/project/obj/models/enums/ItemTpl");
const ConfigTypes_1 = require("C:/snapshot/project/obj/models/enums/ConfigTypes");
const PrefixLogger_1 = require("../util/PrefixLogger");
class FasterCraftingTimeChanger {
    logger;
    tables;
    hideoutConfig;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        const configServer = container.resolve("ConfigServer");
        this.tables = databaseServer.getTables();
        this.hideoutConfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.HIDEOUT);
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            this.doFasterProductionForAll(config.baseCraftingTimeMultiplier);
        }
        catch (error) {
            this.logger.warning("FasterCraftingTime: doFasterProductionForAll failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.hideoutSkillExpFix.enabled) {
                this.doHideoutSkillExpFix(config.hideoutSkillExpFix.hideoutSkillExpMultiplier);
            }
        }
        catch (error) {
            this.logger.warning("FasterCraftingTime: doHideoutSkillExpFix failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.fasterMoonshineProduction.enabled) {
                this.doFasterProductionFor(ItemTpl_1.ItemTpl.DRINK_BOTTLE_OF_FIERCE_HATCHLING_MOONSHINE, config.fasterMoonshineProduction.baseCraftingTimeMultiplier);
            }
        }
        catch (error) {
            this.logger.warning("FasterCraftingTime: doFasterProductionFor DRINK_BOTTLE_OF_FIERCE_HATCHLING_MOONSHINE failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.fasterPurifiedWaterProduction.enabled) {
                this.doFasterProductionFor(ItemTpl_1.ItemTpl.DRINK_CANISTER_WITH_PURIFIED_WATER, config.fasterPurifiedWaterProduction.baseCraftingTimeMultiplier);
            }
        }
        catch (error) {
            this.logger.warning("FasterCraftingTime: doFasterProductionFor DRINK_CANISTER_WITH_PURIFIED_WATER failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.fasterCultistCircle.enabled) {
                this.doFasterCultistCircle(config.fasterCultistCircle.baseCraftingTimeMultiplier);
            }
        }
        catch (error) {
            this.logger.warning("FasterCraftingTime: doFasterCultistCircle DRINK_CANISTER_WITH_PURIFIED_WATER failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doFasterProductionFor(itemTpl, multiplier) {
        const hideout = this.tables.hideout;
        const productionsForItem = hideout.production.recipes.filter((prod) => prod.endProduct === itemTpl);
        if (!productionsForItem) {
            this.logger.warning(`FasterCraftingTime: doFasterProduction: productions for item ${itemTpl} not found, skipping`);
            return;
        }
        for (const production of productionsForItem) {
            production.productionTime = Math.ceil(production.productionTime / multiplier);
        }
    }
    doFasterProductionForAll(multiplier) {
        const exclude = [
            ItemTpl_1.ItemTpl.BARTER_PHYSICAL_BITCOIN,
            ItemTpl_1.ItemTpl.DRINK_BOTTLE_OF_FIERCE_HATCHLING_MOONSHINE,
            ItemTpl_1.ItemTpl.DRINK_CANISTER_WITH_PURIFIED_WATER,
        ];
        const hideout = this.tables.hideout;
        for (const production of hideout.production.recipes) {
            if (!exclude.includes(production.endProduct)) {
                production.productionTime = Math.ceil(production.productionTime / multiplier);
            }
        }
    }
    doHideoutSkillExpFix(multiplier) {
        this.hideoutConfig.hoursForSkillCrafting /= multiplier;
    }
    doFasterCultistCircle(multiplier) {
        this.hideoutConfig.cultistCircle.hideoutTaskRewardTimeSeconds = Math.ceil(this.hideoutConfig.cultistCircle.hideoutTaskRewardTimeSeconds / multiplier);
        for (const craft of this.hideoutConfig.cultistCircle.craftTimeThreshholds) {
            craft.craftTimeSeconds = Math.ceil(craft.craftTimeSeconds / multiplier);
        }
        for (const craft of this.hideoutConfig.cultistCircle.directRewards) {
            craft.craftTimeSeconds = Math.ceil(craft.craftTimeSeconds / multiplier);
            /*
            console.log(
                `${craft.repeatable ? "Repeatable " : ""}Reward: ${craft.reward.map(
                    (x) => this.tables.locales?.global.en[`${x} Name`]
                )} <== Required Items: ${craft.requiredItems.map((x) => this.tables.locales?.global.en[`${x} Name`])}`
            )

            Reward: Secure container Gamma <== Required Items: Secure container Gamma
            Reward: Secure container Kappa <== Required Items: Secure container Theta
            Reward: Cultist figurine <== Required Items: Spooky skull mask
            Reward: Cultist knife <== Required Items: Spooky skull mask,Spooky skull mask,Spooky skull mask,Spooky skull mask,Spooky skull mask
            Reward: Maska-1SCh bulletproof helmet (Killa Edition) <== Required Items: Killa figurine
            Reward: Tagilla's welding mask "Gorilla",Tagilla's welding mask "UBEY" <== Required Items: Tagilla figurine
            Reward: TT-33 7.62x25 TT pistol (Golden) <== Required Items: Reshala figurine
            Reward: Baddie's red beard,Deadlyslob's beard oil <== Required Items: Den figurine
            Reward: Bottle of Tarkovskaya vodka,Bottle of Tarkovskaya vodka,Bottle of Tarkovskaya vodka <== Required Items: Politician Mutkevich figurine
            Reward: Scav Vest,Scav backpack <== Required Items: Scav figurine
            Reward: Obdolbos 2 cocktail injector,Pack of sugar <== Required Items: Ryzhy figurine
            Reward: Grizzly medical kit <== Required Items: BEAR operative figurine
            Reward: HighCom Trooper TFO body armor (MultiCam) <== Required Items: USEC operative figurine
            Repeatable Reward: Bottle of Fierce Hatchling moonshine <== Required Items: Relaxation room key
            Repeatable Reward: Axel parrot figurine <== Required Items: Dundukk sport sunglasses
            Repeatable Reward: Awl <== Required Items: Soap
            Repeatable Reward: Light bulb,Light bulb <== Required Items: Zarya stun grenade
            Repeatable Reward: GreenBat lithium battery,GreenBat lithium battery,Tetriz portable game console,Tetriz portable game console <== Required Items: Physical Bitcoin
            Repeatable Reward: TerraGroup "Blue Folders" materials <== Required Items: LEDX Skin Transilluminator
            */
        }
    }
}
exports.FasterCraftingTimeChanger = FasterCraftingTimeChanger;
//# sourceMappingURL=FasterCraftingTimeChanger.js.map