"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HideoutOptionsChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
const StashOptionsChanger_1 = require("./StashOptionsChanger");
const HideoutContainersChanger_1 = require("./HideoutContainersChanger");
const FasterBitcoinFarmingChanger_1 = require("./FasterBitcoinFarmingChanger");
const FasterCraftingTimeChanger_1 = require("./FasterCraftingTimeChanger");
const FasterHideoutConstructionChanger_1 = require("./FasterHideoutConstructionChanger");
const FuelConsumptionChanger_1 = require("./FuelConsumptionChanger");
const ScavCaseOptionsChanger_1 = require("./ScavCaseOptionsChanger");
class HideoutOptionsChanger {
    container;
    logger;
    tables;
    constructor(container) {
        this.container = container;
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        this.tables = databaseServer.getTables();
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.stashOptions.enabled) {
                new StashOptionsChanger_1.StashOptionsChanger(this.container).apply(config.stashOptions);
            }
        }
        catch (error) {
            this.logger.warning("HideoutOptions: StashOptionsChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.hideoutContainers.enabled) {
                new HideoutContainersChanger_1.HideoutContainersChanger(this.container).apply(config.hideoutContainers);
            }
        }
        catch (error) {
            this.logger.warning("HideoutOptions: HideoutContainersChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.fasterBitcoinFarming.enabled) {
                new FasterBitcoinFarmingChanger_1.FasterBitcoinFarmingChanger(this.container).apply(config.fasterBitcoinFarming);
            }
        }
        catch (error) {
            this.logger.warning("HideoutOptions: FasterBitcoinFarmingChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.fasterCraftingTime.enabled) {
                new FasterCraftingTimeChanger_1.FasterCraftingTimeChanger(this.container).apply(config.fasterCraftingTime);
            }
        }
        catch (error) {
            this.logger.warning("HideoutOptions: FasterCraftingTimeChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.fasterHideoutConstruction.enabled) {
                new FasterHideoutConstructionChanger_1.FasterHideoutConstructionChanger(this.container).apply(config.fasterHideoutConstruction);
            }
        }
        catch (error) {
            this.logger.warning("HideoutOptions: FasterHideoutConstructionChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.fuelConsumption.enabled) {
                new FuelConsumptionChanger_1.FuelConsumptionChanger(this.container).apply(config.fuelConsumption);
            }
        }
        catch (error) {
            this.logger.warning("HideoutOptions: FuelConsumptionChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.scavCaseOptions.enabled) {
                new ScavCaseOptionsChanger_1.ScavCaseOptionsChanger(this.container).apply(config.scavCaseOptions);
            }
        }
        catch (error) {
            this.logger.warning("HideoutOptions: ScavCaseOptionsChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.allowGymTrainingWithMusclePain) {
                this.doAllowGymTrainingWithMusclePain();
            }
        }
        catch (error) {
            this.logger.warning("HideoutOptions: doAllowGymTrainingWithMusclePain failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doAllowGymTrainingWithMusclePain() {
        const globals = this.tables.globals;
        globals.config.Health.Effects.SevereMusclePain.GymEffectivity = 0.75;
    }
}
exports.HideoutOptionsChanger = HideoutOptionsChanger;
//# sourceMappingURL=HideoutOptionsChanger.js.map