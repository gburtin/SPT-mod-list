"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FasterBitcoinFarmingChanger = void 0;
const ItemTpl_1 = require("C:/snapshot/project/obj/models/enums/ItemTpl");
const PrefixLogger_1 = require("../util/PrefixLogger");
class FasterBitcoinFarmingChanger {
    logger;
    databaseServer;
    tables;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        this.databaseServer = container.resolve("DatabaseServer");
        this.tables = this.databaseServer.getTables();
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            this.doFasterBitcoinFarming(config.baseBitcoinTimeMultiplier, config.gpuEfficiency);
        }
        catch (error) {
            this.logger.warning("FasterBitcoinFarming: doFasterBitcoinFarming failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.setBitcoinPriceTo100k) {
                this.setBitcoinPriceTo100k();
            }
        }
        catch (error) {
            this.logger.warning("FasterBitcoinFarming: setBitcoinPriceTo100k failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doFasterBitcoinFarming(baseBitcoinTimeMultiplier, gpuEfficiency) {
        const hideout = this.tables.hideout;
        const bitcoinProductions = hideout.production.recipes.filter((production) => production.endProduct === ItemTpl_1.ItemTpl.BARTER_PHYSICAL_BITCOIN);
        for (const prod of bitcoinProductions) {
            prod.productionTime = Math.round(prod.productionTime / baseBitcoinTimeMultiplier);
        }
        hideout.settings.gpuBoostRate = gpuEfficiency;
    }
    setBitcoinPriceTo100k() {
        const bitcoinHandbook = this.tables.templates?.handbook.Items.find((item) => item.Id === ItemTpl_1.ItemTpl.BARTER_PHYSICAL_BITCOIN);
        bitcoinHandbook.Price = 100000;
    }
}
exports.FasterBitcoinFarmingChanger = FasterBitcoinFarmingChanger;
//# sourceMappingURL=FasterBitcoinFarmingChanger.js.map