"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecureContainerOptionsChanger = void 0;
const ItemTpl_1 = require("C:/snapshot/project/obj/models/enums/ItemTpl");
const Traders_1 = require("C:/snapshot/project/obj/models/enums/Traders");
const recipes_1 = require("../assets/recipes");
const PrefixLogger_1 = require("../util/PrefixLogger");
const ConfigTypes_1 = require("C:/snapshot/project/obj/models/enums/ConfigTypes");
class SecureContainerOptionsChanger {
    logger;
    tables;
    items;
    hideoutConfig;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        this.tables = databaseServer.getTables();
        this.items = this.tables.templates?.items;
        const configServer = container.resolve("ConfigServer");
        this.hideoutConfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.HIDEOUT);
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.progressiveContainers.enabled) {
                this.doProgressiveContainers();
                try {
                    if (config.progressiveContainers.collectorQuestRedone) {
                        this.doCollectorQuestRedone();
                    }
                }
                catch (error) {
                    this.logger.warning("SecureContainerOptions: doCollectorQuestRedone failed gracefully. Send bug report. Continue safely.");
                    console.warn(error);
                }
            }
        }
        catch (error) {
            this.logger.warning("SecureContainerOptions: doProgressiveContainers failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.biggerContainers) {
                this.doBiggerContainers();
            }
        }
        catch (error) {
            this.logger.warning("SecureContainerOptions: doBiggerContainers failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doProgressiveContainers() {
        const profileTemplates = this.tables.templates.profiles;
        for (const profileName of Object.keys(profileTemplates)) {
            const profile = profileTemplates[profileName];
            const bearContainer = profile.bear.character.Inventory.items.find((x) => x.slotId === "SecuredContainer");
            if (bearContainer) {
                bearContainer._tpl = ItemTpl_1.ItemTpl.SECURE_WAIST_POUCH;
            }
            const usecContainer = profile.usec.character.Inventory.items.find((x) => x.slotId === "SecuredContainer");
            if (usecContainer) {
                usecContainer._tpl = ItemTpl_1.ItemTpl.SECURE_WAIST_POUCH;
            }
        }
        const peacekeeper = this.tables.traders?.[Traders_1.Traders.PEACEKEEPER];
        if (peacekeeper?.assort?.items) {
            // "Remove" Beta container from Peacekeeper. Never Delete items from Assorts. This can lead to issues.
            const betaAssortUpd = peacekeeper.assort.items.find((item) => item._tpl === ItemTpl_1.ItemTpl.SECURE_CONTAINER_BETA)?.upd;
            if (betaAssortUpd) {
                betaAssortUpd.UnlimitedCount = false;
                betaAssortUpd.StackObjectsCount = 0;
                betaAssortUpd.BuyRestrictionMax = 0;
            }
        }
        // Block cultistCircle Kappa reward for SECURE_WAIST_POUCH
        // this.hideoutConfig.cultistCircle.directRewards.find((x) => x.requiredItems)
        const reward = this.hideoutConfig.cultistCircle.directRewards.find((reward) => reward.requiredItems.includes("5732ee6a24597719ae0c0281"));
        if (reward) {
            const index = reward.requiredItems.indexOf("5732ee6a24597719ae0c0281");
            if (index !== -1) {
                reward.requiredItems[index] = "5c093ca986f7740a1867ab12";
            }
        }
        // Custom Secure Container recipes
        if (this.tables.hideout?.production) {
            this.tables.hideout.production.recipes.push(...recipes_1.containerRecipes);
        }
    }
    doCollectorQuestRedone() {
        const quests = this.tables.templates.quests;
        const collectorID = Object.keys(quests).find((key) => {
            return quests[key].QuestName === "Collector";
        });
        if (!collectorID) {
            this.logger.warning("SecureContainerOptions: doCollectorQuestRedone: Collector questID");
            return;
        }
        quests[collectorID].conditions.AvailableForFinish.push({
            conditionType: "HandoverItem",
            dogtagLevel: 0,
            id: "639135534b15ca31f76bc319",
            index: 69, // nice
            maxDurability: 100,
            minDurability: 0,
            parentId: "5448bf274bdc2dfc2f8b456a",
            isEncoded: false,
            onlyFoundInRaid: false,
            dynamicLocale: false,
            target: [ItemTpl_1.ItemTpl.SECURE_CONTAINER_GAMMA],
            value: 2,
            visibilityConditions: [],
        });
        this.tables.locales.global.ru["639135534b15ca31f76bc319"] = "Передать носитель"; // Тут нужен только фикс для русского, для всех остальных языков звучит как "Hand over the storage device"
        // Start condition
        quests[collectorID].conditions.AvailableForStart = [
            {
                id: "51d33b2d4fad9e61441772c0",
                compareMethod: ">=",
                conditionType: "Level",
                dynamicLocale: false,
                globalQuestCounterId: "",
                index: 0,
                parentId: "",
                value: 10,
                visibilityConditions: [],
            },
        ];
    }
    doBiggerContainers() {
        this.modifyContainer(ItemTpl_1.ItemTpl.SECURE_WAIST_POUCH, 2, 4);
        this.modifyContainer(ItemTpl_1.ItemTpl.SECURE_CONTAINER_ALPHA, 3, 3);
        this.modifyContainer(ItemTpl_1.ItemTpl.SECURE_CONTAINER_BETA, 3, 4);
        this.modifyContainer(ItemTpl_1.ItemTpl.SECURE_CONTAINER_EPSILON, 3, 5);
        this.modifyContainer(ItemTpl_1.ItemTpl.SECURE_CONTAINER_GAMMA, 4, 5);
        this.modifyContainer(ItemTpl_1.ItemTpl.SECURE_CONTAINER_KAPPA, 5, 5);
    }
    modifyContainer(itemTpl, cellsV, cellsH) {
        if (this.items[itemTpl]?._props.Grids?.[0]._props) {
            this.items[itemTpl]._props.Grids[0]._props.cellsV = cellsV;
            this.items[itemTpl]._props.Grids[0]._props.cellsH = cellsH;
        }
        else {
            this.logger.warning(`Softcore: modifyContainer: Failed to modify container with Tpl ${itemTpl}, skipping`);
        }
    }
}
exports.SecureContainerOptionsChanger = SecureContainerOptionsChanger;
//# sourceMappingURL=SecureContainerOptionsChanger.js.map