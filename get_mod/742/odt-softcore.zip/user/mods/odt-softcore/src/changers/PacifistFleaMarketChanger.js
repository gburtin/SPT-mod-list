"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PacifistFleaMarketChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
const keys_1 = require("../assets/keys");
const ConfigTypes_1 = require("C:/snapshot/project/obj/models/enums/ConfigTypes");
const fleamarket_1 = require("../assets/fleamarket");
class PacifistFleaMarketChanger {
    logger;
    tables;
    ragfairConfig;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        const configServer = container.resolve("ConfigServer");
        this.tables = databaseServer.getTables();
        this.ragfairConfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.RAGFAIR);
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            this.pacifistFleaMarket();
        }
        catch (error) {
            this.logger.warning("PacifistFleaMarket: pacifistFleaMarket failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.whitelist.enabled) {
                this.allowOnRagfair(fleamarket_1.whitelist, config.whitelist.priceMultiplier);
            }
        }
        catch (error) {
            this.logger.warning("PacifistFleaMarket: allowOnRagfair whitelist failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.questKeys.enabled) {
                this.allowOnRagfair(keys_1.questKeys, config.questKeys.priceMultiplier);
            }
        }
        catch (error) {
            this.logger.warning("PacifistFleaMarket: allowOnRagfair questKeys failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.markedKeys.enabled) {
                this.allowOnRagfair(keys_1.markedKeys, config.markedKeys.priceMultiplier);
            }
        }
        catch (error) {
            this.logger.warning("PacifistFleaMarket: allowOnRagfair markedKeys failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    pacifistFleaMarket() {
        const locale = this.tables.locales?.global.en; // debug
        // biome-ignore lint/correctness/noConstantCondition: <explanation>
        if (false) {
            // debug
            // Handbook Categories generator
            const handbookCategories = this.tables.templates.handbook.Categories;
            for (const handbookCategorie in handbookCategories) {
                // console.log(handbookCategories[handbookCategorie].Id)
                console.log(`"${handbookCategories[handbookCategorie].Id}", // ${locale[handbookCategories[handbookCategorie].Id]}`);
            }
        }
        const handbookItems = this.tables.templates?.handbook.Items;
        if (!handbookItems) {
            this.logger.warning("PacifistFleaMarket: handbookItems table not found");
            return;
        }
        const items = this.tables.templates?.items;
        if (!items) {
            this.logger.warning("PacifistFleaMarket: enableWhitelist: items table not found");
            return;
        }
        for (const handbookItem in handbookItems) {
            // For some mAgIcAl reason I can't even remember, this NEEDS to be done in handbookCategories and NOT in BASECLASSES.
            const itemInHandbook = handbookItems[handbookItem];
            const itemID = itemInHandbook.Id;
            // const fleaBarterRequestBlacklistItemsString = fleaBarterRequestBlacklistItems as string[]
            if (!fleamarket_1.fleaListingsWhitelistHandBook.includes(itemInHandbook.ParentId) ||
                items[itemID]._props.QuestItem // ||
            // fleaBarterRequestBlacklistItemsString.includes(itemID)
            ) {
                // Ban everything on flea except whitelist handbook categories.
                this.ragfairConfig.dynamic.blacklist.custom.push(itemID); // Better semantics then CanSellOnRagfair
            }
            // else if (items[itemID]._props.CanSellOnRagfair) {
            // 	// Not banned items THAT CAN BE BOUGHT debug
            // 	console.log(`"${itemID}", // ${locale[`${itemID} Name`]}`)
            // }
            //if (itemInHandbook.ParentId == "6564b96a189fe36f356d177c") {
            //	// debug (armor incerts HB category above)
            //	console.log(`${locale[`${itemID} Name`]}`)
            //}
        }
    }
    allowOnRagfair(whitelist, priceMultiplier) {
        const whitelistItemIDs = whitelist;
        const items = this.tables.templates.items;
        const prices = this.tables.templates.prices;
        for (const itemID of whitelistItemIDs) {
            const item = items[itemID];
            if (!item) {
                this.logger.warning(`PacifistFleaMarket: adjustedSellableOnRagfair: item ${itemID} not found, skipping`);
                continue;
            }
            prices[itemID] = Math.round(prices[itemID] * priceMultiplier);
            item._props.CanSellOnRagfair = true;
            this.ragfairConfig.dynamic.blacklist.custom = this.ragfairConfig.dynamic.blacklist.custom.filter((x) => x !== itemID);
        }
    }
}
exports.PacifistFleaMarketChanger = PacifistFleaMarketChanger;
//# sourceMappingURL=PacifistFleaMarketChanger.js.map