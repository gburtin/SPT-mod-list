"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FasterHideoutConstructionChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
class FasterHideoutConstructionChanger {
    logger;
    databaseServer;
    tables;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        this.databaseServer = container.resolve("DatabaseServer");
        this.tables = this.databaseServer.getTables();
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            this.doFasterHideoutConstruction(config.hideoutConstructionTimeMultiplier);
        }
        catch (error) {
            this.logger.warning("FasterHideoutConstruction: doFasterHideoutConstruction failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doFasterHideoutConstruction(multiplier) {
        const hideout = this.tables.hideout;
        for (const area of hideout.areas) {
            for (const [_, stage] of Object.entries(area.stages)) {
                stage.constructionTime = Math.round(stage.constructionTime / multiplier);
            }
        }
    }
}
exports.FasterHideoutConstructionChanger = FasterHideoutConstructionChanger;
//# sourceMappingURL=FasterHideoutConstructionChanger.js.map