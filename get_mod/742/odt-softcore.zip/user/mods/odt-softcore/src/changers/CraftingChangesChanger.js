"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CraftingChangesChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
const HideoutAreas_1 = require("C:/snapshot/project/obj/models/enums/HideoutAreas");
const productionAdjustments_1 = require("../assets/productionAdjustments");
const recipes_1 = require("../assets/recipes");
class CraftingChangesChanger {
    logger;
    tables;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        this.tables = databaseServer.getTables();
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.craftingRebalance) {
                this.doCraftingRebalance();
            }
        }
        catch (error) {
            this.logger.warning("CraftingChanges: doCraftingRebalance failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.additionalCraftingRecipes) {
                this.doAdditionalCraftingRecipes();
            }
        }
        catch (error) {
            this.logger.warning("CraftingChanges: doAdditionalCraftingRecipes failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doCraftingRebalance() {
        for (const adjustment of productionAdjustments_1.craftingAdjustments) {
            const craft = this.getCraftByEndProduct(adjustment.id);
            if (!craft) {
                this.logger.warning(`CraftingChangesChanger: doCraftingRebalance: craft not found, skipping ${adjustment.id}`);
                continue;
            }
            adjustment.adjust(craft);
        }
    }
    getCraftByEndProduct(endProductID) {
        return this.tables.hideout?.production.recipes.find((production) => production.endProduct === endProductID && production.areaType !== HideoutAreas_1.HideoutAreas.CHRISTMAS_TREE);
    }
    doAdditionalCraftingRecipes() {
        this.tables.hideout?.production.recipes.push(...recipes_1.additionalCraftingRecipes);
    }
}
exports.CraftingChangesChanger = CraftingChangesChanger;
//# sourceMappingURL=CraftingChangesChanger.js.map