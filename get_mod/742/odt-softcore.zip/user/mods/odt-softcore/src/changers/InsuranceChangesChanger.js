"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InsuranceChangesChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
const Traders_1 = require("C:/snapshot/project/obj/models/enums/Traders");
const ConfigTypes_1 = require("C:/snapshot/project/obj/models/enums/ConfigTypes");
class InsuranceChangesChanger {
    logger;
    tables;
    insuranceConfig;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        const ConfigServer = container.resolve("ConfigServer");
        this.tables = databaseServer.getTables();
        this.insuranceConfig = ConfigServer.getConfig(ConfigTypes_1.ConfigTypes.INSURANCE);
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.praporInsuranceChanges.enabled) {
                this.doTraderInsuranceChanges(Traders_1.Traders.PRAPOR, config.praporInsuranceChanges);
            }
        }
        catch (error) {
            this.logger.warning("InsuranceChanges: doTraderInsuranceChanges Traders.PRAPOR failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.therapistInsuranceChanges.enabled) {
                this.doTraderInsuranceChanges(Traders_1.Traders.THERAPIST, config.therapistInsuranceChanges);
            }
        }
        catch (error) {
            this.logger.warning("InsuranceChanges: doTraderInsuranceChanges Traders.THERAPIST failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        // this.insuranceConfig.returnTimeOverrideSeconds = 1
        this.insuranceConfig.runIntervalSeconds = 10;
        this.insuranceConfig.storageTimeOverrideSeconds = 2592000;
    }
    doTraderInsuranceChanges(traderID, insuranceChanges) {
        const trader = this.tables.traders?.[traderID];
        if (!trader) {
            this.logger.error(`Trader ${traderID} not found.`);
            return;
        }
        trader.base.insurance.min_return_hour = insuranceChanges.returnTime.min;
        trader.base.insurance.max_return_hour = insuranceChanges.returnTime.max;
        // trader.base.insurance.max_storage_time = 720
        this.insuranceConfig.returnChancePercent[traderID] = insuranceChanges.returnChance;
        this.insuranceConfig.chanceNoAttachmentsTakenPercent = 50;
        for (const loyaltyLevel of trader.base.loyaltyLevels) {
            loyaltyLevel.insurance_price_coef = insuranceChanges.insuranceCostPercentage;
        }
    }
}
exports.InsuranceChangesChanger = InsuranceChangesChanger;
//# sourceMappingURL=InsuranceChangesChanger.js.map