"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StashOptionsChanger = void 0;
const ItemTpl_1 = require("C:/snapshot/project/obj/models/enums/ItemTpl");
const HideoutAreas_1 = require("C:/snapshot/project/obj/models/enums/HideoutAreas");
const Money_1 = require("C:/snapshot/project/obj/models/enums/Money");
const PrefixLogger_1 = require("../util/PrefixLogger");
class StashOptionsChanger {
    logger;
    databaseServer;
    tables;
    items;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        this.databaseServer = container.resolve("DatabaseServer");
        this.tables = this.databaseServer.getTables();
        this.items = this.tables.templates?.items;
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.progressiveStash) {
                this.doProgressiveStash();
            }
        }
        catch (error) {
            this.logger.warning("StashOptions: doProgressiveStash failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.biggerStash) {
                this.doBiggerStash();
            }
        }
        catch (error) {
            this.logger.warning("StashOptions: doBiggerStash failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.lessCurrencyForConstruction) {
                this.doLessCurrencyForConstruction();
            }
        }
        catch (error) {
            this.logger.warning("StashOptions: doLessCurrencyForConstruction failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.easierLoyalty) {
                this.doEasierLoyalty();
            }
        }
        catch (error) {
            this.logger.warning("StashOptions: doEasierLoyalty failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doProgressiveStash() {
        const profileTemplates = this.tables.templates.profiles;
        const basicStashBonuses = {
            id: "64f5b9e5fa34f11b380756c0",
            templateId: ItemTpl_1.ItemTpl.STASH_STANDARD_STASH_10X30,
            type: "StashSize",
        };
        const startingStashes = [
            ItemTpl_1.ItemTpl.STASH_STANDARD_STASH_10X30,
            ItemTpl_1.ItemTpl.STASH_LEFT_BEHIND_STASH_10X40,
            ItemTpl_1.ItemTpl.STASH_PREPARE_FOR_ESCAPE_STASH_10X50,
            ItemTpl_1.ItemTpl.STASH_EDGE_OF_DARKNESS_STASH_10X68,
            ItemTpl_1.ItemTpl.STASH_THE_UNHEARD_EDITION_STASH_10X72,
        ];
        for (const [profile, _] of Object.entries(profileTemplates)) {
            for (const sidekey of Object.keys(_)) {
                if (sidekey === "descriptionLocaleKey") {
                    continue;
                }
                const side = profileTemplates[profile][sidekey];
                const hideoutArea = side.character.Hideout?.Areas.find((area) => area.type === HideoutAreas_1.HideoutAreas.STASH);
                if (!hideoutArea) {
                    this.logger.warning(`HideoutOptionsChanger: doProgressiveStash: hideoutArea for profile ${_} not found`);
                    continue;
                }
                hideoutArea.level = 1;
                const startingStashItems = side.character.Inventory.items.filter((item) => startingStashes.includes(item._tpl));
                for (const item of startingStashItems) {
                    item._tpl = ItemTpl_1.ItemTpl.STASH_STANDARD_STASH_10X30;
                }
                // Fix for Unheard profiles
                side.character.Bonuses = side.character.Bonuses.filter((x) => x.type !== "StashSize");
                side.character.Bonuses.push(basicStashBonuses);
            }
        }
    }
    doBiggerStash() {
        const stashUpdates = {
            [ItemTpl_1.ItemTpl.STASH_STANDARD_STASH_10X30]: 50,
            [ItemTpl_1.ItemTpl.STASH_LEFT_BEHIND_STASH_10X40]: 100,
            [ItemTpl_1.ItemTpl.STASH_PREPARE_FOR_ESCAPE_STASH_10X50]: 150,
            [ItemTpl_1.ItemTpl.STASH_EDGE_OF_DARKNESS_STASH_10X68]: 200,
            [ItemTpl_1.ItemTpl.STASH_THE_UNHEARD_EDITION_STASH_10X72]: 250,
        };
        for (const [itemTpl, stashSize] of Object.entries(stashUpdates)) {
            const stashItem = this.items[itemTpl];
            if (stashItem?._props?.Grids?.[0]?._props) {
                stashItem._props.Grids[0]._props.cellsV = stashSize;
            }
            else {
                this.logger.warning(`HideoutOptions: doBiggerStash: Failed to modify stash with Tpl ${itemTpl}, skipping`);
            }
        }
    }
    doLessCurrencyForConstruction() {
        const hideoutStashStages = this.tables.hideout.areas.find((area) => area.type === HideoutAreas_1.HideoutAreas.STASH).stages;
        for (const [_, stage] of Object.entries(hideoutStashStages)) {
            const currencyRequirements = stage.requirements.filter((req) => req.templateId === Money_1.Money.ROUBLES || req.templateId === Money_1.Money.EUROS);
            for (const currencyRequirement of currencyRequirements) {
                if (currencyRequirement.count) {
                    currencyRequirement.count /= 10;
                }
            }
        }
    }
    doEasierLoyalty() {
        const hideoutStashStages = this.tables.hideout.areas.find((area) => area.type === HideoutAreas_1.HideoutAreas.STASH).stages;
        for (const [_, stage] of Object.entries(hideoutStashStages)) {
            const loyaltylevels = stage.requirements.filter((req) => req.loyaltyLevel !== undefined);
            for (const loyaltyLevel of loyaltylevels) {
                if (loyaltyLevel.loyaltyLevel !== undefined) {
                    loyaltyLevel.loyaltyLevel -= 1;
                }
            }
        }
    }
}
exports.StashOptionsChanger = StashOptionsChanger;
//# sourceMappingURL=StashOptionsChanger.js.map