"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OtherFleaMarketChangesChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
const ConfigTypes_1 = require("C:/snapshot/project/obj/models/enums/ConfigTypes");
class OtherFleaMarketChangesChanger {
    logger;
    tables;
    ragfairConfig;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        const configServer = container.resolve("ConfigServer");
        this.tables = databaseServer.getTables();
        this.ragfairConfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.RAGFAIR);
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.sellingOnFlea) {
                this.doSellingOnFlea();
            }
        }
        catch (error) {
            this.logger.warning("OtherFleaMarketChanges: doSellingOnFlea failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.onlyFoundInRaidItemsAllowedForBarters) {
                this.adjustOnlyFIRforBarters();
            }
        }
        catch (error) {
            this.logger.warning("OtherFleaMarketChanges: adjustOnlyFIRforBarters failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.fleaPristineItems) {
                this.adjustPristineItems();
            }
        }
        catch (error) {
            this.logger.warning("OtherFleaMarketChanges: adjustPristineItems failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            this.increaseFleaPrices(config.fleaPricesIncreased);
        }
        catch (error) {
            this.logger.warning("OtherFleaMarketChanges: increaseFleaPrices failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doSellingOnFlea() {
        this.ragfairConfig.sell.chance.base = 0;
        this.ragfairConfig.sell.chance.maxSellChancePercent = 0;
    }
    adjustOnlyFIRforBarters() {
        const globals = this.tables.globals;
        globals.config.RagFair.isOnlyFoundInRaidAllowed = true;
    }
    adjustPristineItems() {
        //This should disable randomised item condition.
        for (const condition of Object.values(this.ragfairConfig.dynamic.condition)) {
            condition.conditionChance = 0;
        }
    }
    increaseFleaPrices(priceMultiplier) {
        this.ragfairConfig.dynamic.priceRanges.default.max *= priceMultiplier;
        this.ragfairConfig.dynamic.priceRanges.default.min *= priceMultiplier;
    }
}
exports.OtherFleaMarketChangesChanger = OtherFleaMarketChangesChanger;
//# sourceMappingURL=OtherFleaMarketChangesChanger.js.map