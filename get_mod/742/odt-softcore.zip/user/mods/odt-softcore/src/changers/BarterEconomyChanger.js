"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BarterEconomyChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
const ConfigTypes_1 = require("C:/snapshot/project/obj/models/enums/ConfigTypes");
const fleamarket_1 = require("../assets/fleamarket");
const BaseClasses_1 = require("C:/snapshot/project/obj/models/enums/BaseClasses");
class BarterEconomyChanger {
    logger;
    tables;
    ragfairConfig;
    itemconfig;
    itemHelper;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        const configServer = container.resolve("ConfigServer");
        this.itemHelper = container.resolve("ItemHelper");
        this.tables = databaseServer.getTables();
        this.ragfairConfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.RAGFAIR);
        this.itemconfig = configServer.getConfig(ConfigTypes_1.ConfigTypes.ITEM);
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            this.doBarterEconomy();
        }
        catch (error) {
            this.logger.warning("\n BarterEconomy: doBarterEconomy failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            this.adjustCashOffers(config.cashOffersPercentage);
        }
        catch (error) {
            this.logger.warning("\n BarterEconomy: adjustCashOffers failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            this.adjustBarterPriceVariance(config.barterPriceVariance);
        }
        catch (error) {
            this.logger.warning("\n BarterEconomy: adjustBarterPriceVariance failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            this.adjustItemCountMax(config.itemCountMax);
        }
        catch (error) {
            this.logger.warning("\n BarterEconomy: adjustItemCountMax failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            this.adjustOfferItemCount(config.offerItemCount);
        }
        catch (error) {
            this.logger.warning("\n BarterEconomy: adjustOfferItemCount failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            this.adjustNonStackableAmount(config.nonStackableCount);
        }
        catch (error) {
            this.logger.warning("\n BarterEconomy: adjustNonStackableAmount failed gracefully. Send bug report. Continue safely.");
            console.log(error);
        }
    }
    doBarterEconomy() {
        const locale = this.tables.locales?.global.en; // debug
        const barterBlacklist = Object.values(BaseClasses_1.BaseClasses).filter((baseClass) => !fleamarket_1.fleaBarterRequestWhitelist.includes(baseClass));
        this.ragfairConfig.dynamic.barter.itemTypeBlacklist = barterBlacklist;
        this.ragfairConfig.dynamic.barter.minRoubleCostToBecomeBarter = 100;
        // this.ragfairConfig.dynamic.barter.itemTypeBlacklist.forEach((x) => console.log(`"${x}", // ${locale[`${x} Name`]}`)) // log blacklisted for buying baseclasses
        const items = this.tables.templates?.items;
        if (!items) {
            this.logger.warning("BarterEconomyChanger: doBarterEconomy: Handbook not found, skipping price adjust");
            return;
        }
        const fleaPrices = this.tables.templates?.prices;
        if (!fleaPrices) {
            this.logger.warning("BarterEconomyChanger: doBarterEconomy: tables.templates.prices not found");
            return;
        }
        for (const item in items) {
            if (items[item]._type === "Item" &&
                !this.itemHelper.isOfBaseclasses(item, this.ragfairConfig.dynamic.barter.itemTypeBlacklist) &&
                items[item]._parent !== BaseClasses_1.BaseClasses.MONEY) {
                if (items[item]._props.QuestItem === true) {
                    // Block quest items from being requested on flea
                    // console.log(`"${item}": ${fleaPrices[item]} // ${locale[`${item} Name`]}`)
                    fleaPrices[item] = 0;
                }
                else if (!items[item]._props.CanSellOnRagfair) {
                    // Block every other shady item
                    // console.log(`"${item}": ${fleaPrices[item]} // ${locale[`${item} Name`]}`)
                    fleaPrices[item] = 0;
                    // console.log(`${item}, // ${locale[`${item} Name`]}, ${fleaPrices[item]}`)
                }
                else {
                    if (fleamarket_1.BSGblacklist.includes(item) && items[item]._props.CanSellOnRagfair === true) {
                        this.logger.warning(`\nItem ${locale?.[`${item} Name`]} can be bought on flea, don't use BSG blacklist unlockers with Barter Economy enabled!`);
                    }
                    // Log for whitelisted items for barter REQUESTS
                    // console.log(`"${item}": ${fleaPrices[item]} // ${this.tables.locales?.global.en[`${item} Name`]}`)
                }
            }
        }
        for (const item in fleamarket_1.requestWhitelist) {
            // Unblock for requests otherwise blocked items from requestWhitelist
            fleaPrices[item] = fleamarket_1.requestWhitelist[item];
        }
    }
    adjustCashOffers(cashOffersPercentage) {
        this.ragfairConfig.dynamic.barter.chancePercent = 100 - cashOffersPercentage;
    }
    adjustBarterPriceVariance(barterPriceVariance) {
        this.ragfairConfig.dynamic.barter.priceRangeVariancePercent = barterPriceVariance;
    }
    adjustItemCountMax(itemCountMax) {
        this.ragfairConfig.dynamic.barter.itemCountMax = itemCountMax;
    }
    adjustOfferItemCount(minMaxRecord) {
        this.ragfairConfig.dynamic.offerItemCount = minMaxRecord;
    }
    adjustNonStackableAmount(minMaxRecord) {
        this.ragfairConfig.dynamic.nonStackableCount = minMaxRecord;
    }
}
exports.BarterEconomyChanger = BarterEconomyChanger;
//# sourceMappingURL=BarterEconomyChanger.js.map