"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EconomyOptionsChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
const PriceRebalanceChanger_1 = require("./PriceRebalanceChanger");
const PacifistFleaMarketChanger_1 = require("./PacifistFleaMarketChanger");
const BarterEconomyChanger_1 = require("./BarterEconomyChanger");
const OtherFleaMarketChangesChanger_1 = require("./OtherFleaMarketChangesChanger");
class EconomyOptionsChanger {
    container;
    logger;
    tables;
    constructor(container) {
        this.container = container;
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        this.tables = databaseServer.getTables();
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.disableFleaMarketCompletely) {
                this.doDisableFleaMarketCompletely();
                return;
            }
        }
        catch (error) {
            this.logger.warning("EconomyOptions: doDisableFleaMarketCompletely failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.priceRebalance.enabled) {
                new PriceRebalanceChanger_1.PriceRebalanceChanger(this.container).apply(config.priceRebalance);
            }
        }
        catch (error) {
            this.logger.warning("EconomyOptions: PriceRebalanceChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.pacifistFleaMarket.enabled) {
                new PacifistFleaMarketChanger_1.PacifistFleaMarketChanger(this.container).apply(config.pacifistFleaMarket);
            }
        }
        catch (error) {
            this.logger.warning("EconomyOptions: PacifistFleaMarketChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.barterEconomy.enabled) {
                new BarterEconomyChanger_1.BarterEconomyChanger(this.container).apply(config.barterEconomy);
            }
        }
        catch (error) {
            this.logger.warning("EconomyOptions: BarterEconomyChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.otherFleaMarketChanges.enabled) {
                new OtherFleaMarketChangesChanger_1.OtherFleaMarketChangesChanger(this.container).apply(config.otherFleaMarketChanges);
                this.updateRagfairMinUserLevel(config.otherFleaMarketChanges.fleaMarketOpenAtLevel);
            }
        }
        catch (error) {
            this.logger.warning("EconomyOptions: OtherFleaMarketChangesChanger failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doDisableFleaMarketCompletely() {
        this.updateRagfairMinUserLevel(99);
    }
    updateRagfairMinUserLevel(level) {
        const globals = this.tables.globals;
        globals.config.RagFair.minUserLevel = level;
    }
}
exports.EconomyOptionsChanger = EconomyOptionsChanger;
//# sourceMappingURL=EconomyOptionsChanger.js.map