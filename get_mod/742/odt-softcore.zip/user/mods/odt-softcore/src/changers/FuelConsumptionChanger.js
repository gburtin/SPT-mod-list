"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FuelConsumptionChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
class FuelConsumptionChanger {
    logger;
    databaseServer;
    tables;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        this.databaseServer = container.resolve("DatabaseServer");
        this.tables = this.databaseServer.getTables();
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            this.doChangeFuelConsumption(config.fuelConsumptionMultiplier);
        }
        catch (error) {
            this.logger.warning("FuelConsumption: doChangeFuelConsumption failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doChangeFuelConsumption(multiplier) {
        const hideout = this.tables.hideout;
        hideout.settings.generatorFuelFlowRate *= multiplier; // сука. 33 строчки чтобы изменить одну переменную.
    }
}
exports.FuelConsumptionChanger = FuelConsumptionChanger;
//# sourceMappingURL=FuelConsumptionChanger.js.map