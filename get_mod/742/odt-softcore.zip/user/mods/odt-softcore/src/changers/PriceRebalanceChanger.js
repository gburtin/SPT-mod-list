"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PriceRebalanceChanger = void 0;
const PrefixLogger_1 = require("../util/PrefixLogger");
const ItemTpl_1 = require("C:/snapshot/project/obj/models/enums/ItemTpl");
class PriceRebalanceChanger {
    logger;
    tables;
    handbookHelper;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        const databaseServer = container.resolve("DatabaseServer");
        this.tables = databaseServer.getTables();
        this.handbookHelper = container.resolve("HandbookHelper");
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.itemFixes) {
                this.doItemFixes();
            }
        }
        catch (error) {
            this.logger.warning("PriceRebalance: doItemFixes markedKeys failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            this.doPriceRebalance();
        }
        catch (error) {
            this.logger.warning("PacifistFleaMarket: doPriceRebalance markedKeys failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doItemFixes() {
        const itemsToFix = {
            [ItemTpl_1.ItemTpl.VISORS_ROUND_FRAME_SUNGLASSES]: 3084 * 5,
            [ItemTpl_1.ItemTpl.AMMO_40MMRU_VOG25]: 6750 * 5,
            [ItemTpl_1.ItemTpl.VISORS_ANTIFRAGMENTATION_GLASSES]: 2181 * 2,
            [ItemTpl_1.ItemTpl.BACKPACK_LOLKEK_3F_TRANSFER_TOURIST]: 18000 * 2,
            [ItemTpl_1.ItemTpl.FOOD_EMELYA_RYE_CROUTONS]: 1500,
            [ItemTpl_1.ItemTpl.FOOD_RYE_CROUTONS]: 2000,
            [ItemTpl_1.ItemTpl.INFO_INTELLIGENCE_FOLDER]: 588000,
            [ItemTpl_1.ItemTpl.INFO_MILITARY_FLASH_DRIVE]: 224400,
            "67449b6c89d5e1ddc603f504": 32524 * 20, // Skier contraband case key
        };
        for (const [itemTpl, price] of Object.entries(itemsToFix)) {
            const item = this.tables.templates.handbook.Items.find((item) => item.Id === itemTpl);
            if (!item) {
                this.logger.error(`Item ${itemTpl} not found in handbook`);
                return;
            }
            item.Price = price;
        }
        this.handbookHelper.hydrateLookup();
    }
    doPriceRebalance() {
        const handbookItems = this.tables.templates.handbook.Items;
        const fleaPrices = this.tables.templates.prices;
        for (const item of handbookItems) {
            fleaPrices[item.Id] = item.Price;
        }
    }
}
exports.PriceRebalanceChanger = PriceRebalanceChanger;
//# sourceMappingURL=PriceRebalanceChanger.js.map