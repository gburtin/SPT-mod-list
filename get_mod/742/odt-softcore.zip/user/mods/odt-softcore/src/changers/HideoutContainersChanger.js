"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HideoutContainersChanger = void 0;
const ItemTpl_1 = require("C:/snapshot/project/obj/models/enums/ItemTpl");
const PrefixLogger_1 = require("../util/PrefixLogger");
class HideoutContainersChanger {
    logger;
    databaseServer;
    tables;
    items;
    constructor(container) {
        this.logger = PrefixLogger_1.PrefixLogger.getInstance();
        this.databaseServer = container.resolve("DatabaseServer");
        this.tables = this.databaseServer.getTables();
        this.items = this.tables.templates?.items;
    }
    apply(config) {
        if (!config.enabled) {
            return;
        }
        try {
            if (config.biggerHideoutContainers) {
                this.doBiggerHideoutContainers();
            }
        }
        catch (error) {
            this.logger.warning("HideoutContainers: doBiggerHideoutContainers failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
        try {
            if (config.siccCaseBuff) {
                this.doSiccCaseBuff();
            }
        }
        catch (error) {
            this.logger.warning("HideoutContainers: doSiccCaseBuff failed gracefully. Send bug report. Continue safely.");
            console.warn(error);
        }
    }
    doBiggerHideoutContainers() {
        const containersToModify = [
            { tpl: ItemTpl_1.ItemTpl.CONTAINER_MEDICINE_CASE, cellsH: 10, cellsV: 10 },
            { tpl: ItemTpl_1.ItemTpl.CONTAINER_MR_HOLODILNICK_THERMAL_BAG, cellsH: 10, cellsV: 10 },
            { tpl: ItemTpl_1.ItemTpl.CONTAINER_MAGAZINE_CASE, cellsH: 10, cellsV: 7 },
            { tpl: ItemTpl_1.ItemTpl.CONTAINER_ITEM_CASE, cellsH: 10, cellsV: 10 },
            { tpl: ItemTpl_1.ItemTpl.CONTAINER_WEAPON_CASE, cellsH: 6, cellsV: 15 },
            { tpl: ItemTpl_1.ItemTpl.CONTAINER_KEY_TOOL, cellsH: 5, cellsV: 5 },
            { tpl: ItemTpl_1.ItemTpl.CONTAINER_THICC_WEAPON_CASE, cellsH: 14, cellsV: 15 },
        ];
        for (const container of containersToModify) {
            const item = this.items?.[container.tpl];
            if (item?._props?.Grids?.[0]?._props) {
                item._props.Grids[0]._props.cellsH = container.cellsH;
                item._props.Grids[0]._props.cellsV = container.cellsV;
            }
            else {
                this.logger.warning(`doBiggerHideoutContainers: ${container.tpl} not found.`);
            }
        }
    }
    doSiccCaseBuff() {
        // Huge buff to SICC case to make it actually not shit and a direct upgrade to Docs. And while we are here, allow it to hold keytool. It's Softcore, who
        const docsFilter = this.items?.[ItemTpl_1.ItemTpl.CONTAINER_DOCUMENTS_CASE]._props.Grids?.[0]._props.filters[0].Filter;
        const siccFilter = this.items?.[ItemTpl_1.ItemTpl.CONTAINER_SICC]._props.Grids?.[0]._props.filters[0].Filter;
        if (!docsFilter || !siccFilter) {
            this.logger.warning("HideoutContainers: doSiccCaseBuff: docsFilter or siccFilter not found");
            return;
        }
        const mergeFilters = [...new Set([...docsFilter, ...siccFilter, ItemTpl_1.ItemTpl.CONTAINER_KEY_TOOL])];
        this.items[ItemTpl_1.ItemTpl.CONTAINER_SICC]._props.Grids[0]._props.filters[0].Filter = mergeFilters;
        // this.items[ItemTpl.CONTAINER_SICC]._props.Grids[0]._props.filters[0].Filter.forEach((x) => {
        // 	console.log(this.tables.locales?.global.en[`${x} Name`])
        // })
    }
}
exports.HideoutContainersChanger = HideoutContainersChanger;
//# sourceMappingURL=HideoutContainersChanger.js.map