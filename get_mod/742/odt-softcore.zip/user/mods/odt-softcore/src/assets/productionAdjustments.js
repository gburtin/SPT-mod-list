"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.craftingAdjustments = void 0;
const ItemTpl_1 = require("C:/snapshot/project/obj/models/enums/ItemTpl");
exports.craftingAdjustments = [
    {
        id: ItemTpl_1.ItemTpl.BARTER_TOILET_PAPER,
        adjust: (craft) => {
            craft.count = 1;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_CLIN_WINDOW_CLEANER,
        adjust: (craft) => {
            craft.count = 4;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_PARACORD,
        adjust: (craft) => {
            craft.count = 2;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_CORRUGATED_HOSE,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 1;
                }
            }
            craft.count = 1;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_WATER_FILTER,
        adjust: (craft) => {
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_GAS_MASK_AIR_FILTER);
            if (!requirement) {
                return;
            }
            requirement.count = 2;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.DRINK_EMERGENCY_WATER_RATION,
        adjust: (craft) => {
            craft.count = 3;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_CAN_OF_MAJAICA_COFFEE_BEANS,
        adjust: (craft) => {
            craft.count = 3;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.DRINK_BOTTLE_OF_WATER_06L,
        adjust: (craft) => {
            craft.count = 16;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.STIM_MULE_STIMULANT_INJECTOR,
        adjust: (craft) => {
            craft.count = 2;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.STIM_ETGCHANGE_REGENERATIVE_STIMULANT_INJECTOR,
        adjust: (craft) => {
            craft.count = 2;
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.MEDICAL_CALOKB_HEMOSTATIC_APPLICATOR);
            if (!requirement) {
                return;
            }
            requirement.count = 2;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.MEDKIT_AFAK_TACTICAL_INDIVIDUAL_FIRST_AID_KIT,
        adjust: (craft) => {
            let requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.MEDKIT_IFAK_INDIVIDUAL_FIRST_AID_KIT);
            if (!requirement) {
                return;
            }
            requirement.count = 1;
            requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.MEDICAL_ARMY_BANDAGE);
            if (!requirement) {
                return;
            }
            requirement.templateId = ItemTpl_1.ItemTpl.MEDICAL_CALOKB_HEMOSTATIC_APPLICATOR;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.MEDICAL_SURV12_FIELD_SURGICAL_KIT,
        adjust: (craft) => {
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.MEDICAL_SURV12_FIELD_SURGICAL_KIT);
            if (!requirement) {
                return;
            }
            requirement.count = 2;
            requirement.templateId = ItemTpl_1.ItemTpl.MEDICAL_CMS_SURGICAL_KIT;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_PORTABLE_DEFIBRILLATOR,
        adjust: (craft) => {
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_PORTABLE_POWERBANK);
            if (!requirement) {
                return;
            }
            requirement.count = 4;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_LEDX_SKIN_TRANSILLUMINATOR,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 1;
                }
            }
        },
    },
    {
        id: ItemTpl_1.ItemTpl.MEDICAL_CMS_SURGICAL_KIT,
        adjust: (craft) => {
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_MEDICAL_TOOLS);
            if (!requirement) {
                return;
            }
            requirement.count = 2;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.MEDKIT_GRIZZLY_MEDICAL_KIT,
        adjust: (craft) => {
            craft.count = 1;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.STIM_SJ6_TGLABS_COMBAT_STIMULANT_INJECTOR,
        adjust: (craft) => {
            craft.count = 3;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.INFO_TOPOGRAPHIC_SURVEY_MAPS,
        adjust: (craft) => {
            craft.count = 2;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.INFO_MILITARY_FLASH_DRIVE,
        adjust: (craft) => {
            craft.count = 1;
            let requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.INFO_SECURE_FLASH_DRIVE);
            if (!requirement) {
                return;
            }
            requirement.templateId = ItemTpl_1.ItemTpl.BARTER_VPX_FLASH_STORAGE_MODULE;
            requirement = craft.requirements.find((requirement) => requirement.type === "Area");
            if (!requirement) {
                return;
            }
            requirement.requiredLevel = 2;
            // biome-ignore lint/complexity/noForEach: smol boi
            craft.requirements.forEach((x) => {
                if (x.count) {
                    x.count = 1;
                }
            });
        },
    },
    {
        id: ItemTpl_1.ItemTpl.INFO_INTELLIGENCE_FOLDER,
        adjust: (craft) => {
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.INFO_MILITARY_FLASH_DRIVE);
            if (!requirement) {
                return;
            }
            requirement.count = 1;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_VPX_FLASH_STORAGE_MODULE,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 2;
                }
            }
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_VIRTEX_PROGRAMMABLE_PROCESSOR,
        adjust: (craft) => {
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_MILITARY_CIRCUIT_BOARD);
            if (!requirement) {
                return;
            }
            requirement.count = 1;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_GRAPHICS_CARD,
        adjust: (craft) => {
            let requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_VPX_FLASH_STORAGE_MODULE);
            if (!requirement) {
                return;
            }
            requirement.count = 1;
            requirement.templateId = ItemTpl_1.ItemTpl.BARTER_VIRTEX_PROGRAMMABLE_PROCESSOR;
            requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_PC_CPU);
            if (!requirement) {
                return;
            }
            requirement.count = 1;
            requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_PRINTED_CIRCUIT_BOARD);
            if (!requirement) {
                return;
            }
            requirement.count = 1;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_MILITARY_CIRCUIT_BOARD,
        adjust: (craft) => {
            craft.count = 2;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.SPECIALSCOPE_FLIR_RS32_2259X_35MM_60HZ_THERMAL_RIFLESCOPE,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 1;
                }
                if (requirement.templateId === ItemTpl_1.ItemTpl.INFO_SAS_DRIVE) {
                    requirement.templateId = ItemTpl_1.ItemTpl.SPECIALSCOPE_ARMASIGHT_VULCAN_MG_35X_BRAVO_NIGHT_VISION_SCOPE;
                }
            }
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_UHF_RFID_READER,
        adjust: (craft) => {
            craft.requirements = [
                {
                    areaType: 11,
                    requiredLevel: 2,
                    type: "Area",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_BROKEN_GPHONE_X_SMARTPHONE,
                    count: 1,
                    isFunctional: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.SPECITEM_SIGNAL_JAMMER,
                    count: 1,
                    isFunctional: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_FLAT_SCREWDRIVER_LONG,
                    type: "Tool",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_FLAT_SCREWDRIVER,
                    type: "Tool",
                },
                {
                    type: "QuestComplete",
                    questId: "63966fccac6f8f3c677b9d89",
                },
            ];
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_GAS_ANALYZER,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 1;
                }
            }
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_GUNPOWDER_HAWK,
        adjust: (craft) => {
            let requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_CLASSIC_MATCHES);
            if (!requirement) {
                return;
            }
            requirement.templateId = ItemTpl_1.ItemTpl.BARTER_CAN_OF_THERMITE;
            requirement = craft.requirements.find((requirement) => requirement.type === "Area");
            if (!requirement) {
                return;
            }
            requirement.requiredLevel = 2;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_SPARK_PLUG,
        adjust: (craft) => {
            craft.count = 4;
        },
    },
    {
        // this will break
        id: ItemTpl_1.ItemTpl.BARTER_PRINTED_CIRCUIT_BOARD,
        adjust: (craft) => {
            craft.count = 3;
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_GAS_ANALYZER);
            if (!requirement) {
                return;
            }
            requirement.templateId = ItemTpl_1.ItemTpl.BARTER_GEIGERMULLER_COUNTER;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_GEIGERMULLER_COUNTER,
        adjust: (craft) => {
            craft.requirements = [
                {
                    areaType: 10,
                    requiredLevel: 1,
                    type: "Area",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_GAS_ANALYZER,
                    count: 1,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_TOOLSET,
                    type: "Tool",
                },
            ];
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_GREENBAT_LITHIUM_BATTERY,
        adjust: (craft) => {
            craft.count = 2;
            craft.requirements = [
                {
                    areaType: 10,
                    requiredLevel: 2,
                    type: "Area",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_PORTABLE_POWERBANK,
                    count: 1,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_ROUND_PLIERS,
                    type: "Tool",
                },
            ];
        },
    },
    {
        id: ItemTpl_1.ItemTpl.GRENADE_VOG25_KHATTABKA_IMPROVISED_HAND,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 2;
                }
            }
        },
    },
    {
        id: ItemTpl_1.ItemTpl.AMMO_23X75_ZVEZDA,
        adjust: (craft) => {
            craft.count = 20;
            craft.requirements = [
                {
                    areaType: 10,
                    requiredLevel: 2,
                    type: "Area",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_GUNPOWDER_EAGLE,
                    count: 1,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.AMMO_23X75_SHRAP10,
                    count: 20,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.GRENADE_ZARYA_STUN,
                    count: 2,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_TOOLSET,
                    type: "Tool",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.MULTITOOLS_LEATHERMAN_MULTITOOL,
                    type: "Tool",
                },
            ];
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_RECHARGEABLE_BATTERY,
        adjust: (craft) => {
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.BARTER_PORTABLE_POWERBANK);
            if (!requirement) {
                return;
            }
            requirement.templateId = ItemTpl_1.ItemTpl.BARTER_ELECTRIC_DRILL;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.BARTER_CAN_OF_THERMITE,
        adjust: (craft) => {
            const requirement = craft.requirements.find((requirement) => requirement.templateId === ItemTpl_1.ItemTpl.KEY_DORM_ROOM_308);
            if (!requirement) {
                return;
            }
            requirement.templateId = ItemTpl_1.ItemTpl.KNIFE_BARS_A2607_DAMASCUS;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.AMMO_45ACP_AP,
        adjust: (craft) => {
            craft.count = 120;
            craft.requirements = [
                {
                    areaType: 10,
                    requiredLevel: 2,
                    type: "Area",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.AMMO_45ACP_LASERMATCH,
                    count: 120,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.MULTITOOLS_LEATHERMAN_MULTITOOL,
                    type: "Tool",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_GUNPOWDER_EAGLE,
                    count: 1,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_PACK_OF_NAILS,
                    count: 1,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_SET_OF_FILES_MASTER,
                    type: "Tool",
                },
            ];
        },
    },
    //	{
    //		id: ItemTpl.AMMO_57X28_SS190,
    //		adjust: (craft: IHideoutProduction) => {
    //			craft.requirements = [
    //				{
    //					areaType: 10,
    //					requiredLevel: 2,
    //					type: "Area",
    //				},
    //				{
    //					templateId: ItemTpl.BARTER_HAND_DRILL,
    //					type: "Tool",
    //				},
    //				{
    //					templateId: ItemTpl.BARTER_PLIERS_ELITE,
    //					type: "Tool",
    //				},
    //				{
    //					templateId: ItemTpl.AMMO_57X28_SS197SR,
    //					count: 180,
    //					isFunctional: false,
    //					isEncoded: false,
    //					type: "Item",
    //				},
    //				{
    //					templateId: ItemTpl.BARTER_GUNPOWDER_HAWK,
    //					count: 1,
    //					isFunctional: false,
    //					isEncoded: false,
    //					type: "Item",
    //				},
    //				{
    //					templateId: ItemTpl.BARTER_PACK_OF_NAILS,
    //					count: 2,
    //					isFunctional: false,
    //					isEncoded: false,
    //					type: "Item",
    //				},
    //			]
    //		},
    //	},
    {
        id: ItemTpl_1.ItemTpl.AMMO_556X45_SOST,
        adjust: (craft) => {
            craft.requirements = [
                {
                    areaType: 10,
                    requiredLevel: 2,
                    type: "Area",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.AMMO_556X45_HP,
                    count: 150,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_GUNPOWDER_EAGLE,
                    count: 1,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_PLIERS_ELITE,
                    type: "Tool",
                },
            ];
        },
    },
    {
        id: ItemTpl_1.ItemTpl.AMMO_9X18PM_PSTM,
        adjust: (craft) => {
            craft.requirements.push({
                templateId: ItemTpl_1.ItemTpl.AMMO_9X18PM_PST,
                count: 140,
                isFunctional: false,
                isEncoded: false,
                type: "Item",
            });
        },
    },
    {
        id: ItemTpl_1.ItemTpl.AMMO_12G_AP20,
        adjust: (craft) => {
            craft.requirements = [
                {
                    areaType: 10,
                    requiredLevel: 2,
                    type: "Area",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.AMMO_12G_MAGNUM,
                    count: 80,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.AMMO_9X19_AP_63,
                    count: 80,
                    isFunctional: false,
                    isEncoded: false,
                    type: "Item",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_NIPPERS,
                    type: "Tool",
                },
                {
                    templateId: ItemTpl_1.ItemTpl.BARTER_FLAT_SCREWDRIVER_LONG,
                    type: "Tool",
                },
                {
                    type: "QuestComplete",
                    questId: "6179ad0a6e9dd54ac275e3f2",
                },
            ];
        },
    },
    //	{
    //		id: ItemTpl.AMMO_366TKM_APM,
    //		adjust: (craft: IHideoutProduction) => {
    //			craft.requirements = [
    //				{
    //					areaType: 10,
    //					requiredLevel: 2,
    //					type: "Area",
    //				},
    //				{
    //					templateId: ItemTpl.AMMO_9X39_SPP,
    //					count: 100,
    //					isFunctional: false,
    //					isEncoded: false,
    //					type: "Item",
    //				},
    //				{
    //					templateId: ItemTpl.AMMO_762X39_HP,
    //					count: 100,
    //					isFunctional: false,
    //					isEncoded: false,
    //					type: "Item",
    //				},
    //				{
    //					templateId: ItemTpl.BARTER_PLIERS,
    //					type: "Tool",
    //				},
    //				{
    //					type: "QuestComplete",
    //					questId: "5bc47dbf86f7741ee74e93b9",
    //				},
    //			]
    //		},
    //	},
    {
        id: ItemTpl_1.ItemTpl.BARTER_OFZ_30X165MM_SHELL,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 1;
                }
            }
        },
    },
    {
        id: ItemTpl_1.ItemTpl.GRENADE_RGD5_HAND,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 1;
                }
            }
        },
    },
    {
        id: ItemTpl_1.ItemTpl.GRENADE_ZARYA_STUN,
        adjust: (craft) => {
            for (const requirement of craft.requirements) {
                if (requirement.count) {
                    requirement.count = 1;
                }
            }
        },
    },
    {
        id: ItemTpl_1.ItemTpl.AMMO_12G_PIRANHA,
        adjust: (craft) => {
            craft.count = 150;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.AMMO_545X39_BP,
        adjust: (craft) => {
            craft.count = 180;
        },
    },
    {
        id: ItemTpl_1.ItemTpl.AMMO_556X45_M855A1,
        adjust: (craft) => {
            craft.count = 180;
        },
    },
];
//# sourceMappingURL=productionAdjustments.js.map