"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.markedKeys = exports.questKeys = void 0;
const ItemTpl_1 = require("C:/snapshot/project/obj/models/enums/ItemTpl");
exports.questKeys = [
    // Whitelist for quest keys updated for 3.10 taken from the Wiki some are commented out for balancing
    //Factory
    ItemTpl_1.ItemTpl.KEY_FACTORY_EMERGENCY_EXIT,
    ItemTpl_1.ItemTpl.KEYCARD_TERRAGROUP_STORAGE_ROOM,
    //Customs
    ItemTpl_1.ItemTpl.KEY_DORM_OVERSEER,
    ItemTpl_1.ItemTpl.KEY_DORM_ROOM_114,
    //ItemTpl.KEY_DORM_ROOM_203,
    //ItemTpl.KEY_DORM_ROOM_206,
    ItemTpl_1.ItemTpl.KEY_DORM_ROOM_214,
    ItemTpl_1.ItemTpl.KEY_DORM_ROOM_220,
    ItemTpl_1.ItemTpl.KEY_DORM_ROOM_303,
    //ItemTpl.KEY_DORM_ROOM_314_MARKED,
    //ItemTpl.KEY_MACHINERY,
    ItemTpl_1.ItemTpl.KEY_PORTABLE_BUNKHOUSE,
    //ItemTpl.KEY_TARCONE_DIRECTORS_OFFICE,
    //ItemTpl.KEY_TRAILER_PARK_PORTABLE_CABIN,
    //ItemTpl.KEY_UNKNOWN,
    //Woods
    //ItemTpl.KEY_SHTURMANS_STASH,
    ItemTpl_1.ItemTpl.KEY_ZB014,
    //Shoreline
    ItemTpl_1.ItemTpl.KEY_COTTAGE_BACK_DOOR,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_EAST_WING_ROOM_306,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_EAST_WING_ROOM_308,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_EAST_WING_ROOM_328,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_OFFICE_KEY_WITH_A_BLUE_TAPE,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_WEST_WING_OFFICE_ROOM_112,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_WEST_WING_ROOM_216,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_WEST_WING_ROOM_219,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_WEST_WING_ROOM_220,
    ItemTpl_1.ItemTpl.KEY_HEALTH_RESORT_WEST_WING_ROOM_306,
    //Interchange
    ItemTpl_1.ItemTpl.KEY_EMERCOM_MEDICAL_UNIT,
    ItemTpl_1.ItemTpl.KEY_GOSHAN_CASH_REGISTER,
    ItemTpl_1.ItemTpl.KEY_KIBA_ARMS_INNER_GRATE_DOOR,
    ItemTpl_1.ItemTpl.KEY_KIBA_ARMS_OUTER_DOOR,
    ItemTpl_1.ItemTpl.KEYCARD_OBJECT_11SR,
    ItemTpl_1.ItemTpl.KEYCARD_OBJECT_21WS,
    ItemTpl_1.ItemTpl.KEY_OLI_LOGISTICS_DEPARTMENT_OFFICE,
    //TheLab
    ItemTpl_1.ItemTpl.KEYCARD_WITH_A_BLUE_MARKING,
    //ItemTpl.KEYCARD_TERRAGROUP_LABS_ACCESS,
    ItemTpl_1.ItemTpl.KEYCARD_TERRAGROUP_LABS_KEYCARD_BLACK,
    ItemTpl_1.ItemTpl.KEY_TERRAGROUP_LABS_MANAGERS_OFFICE_ROOM,
    ItemTpl_1.ItemTpl.KEY_TERRAGROUP_LABS_WEAPON_TESTING_AREA,
    //Reserve
    ItemTpl_1.ItemTpl.KEY_RBKSM,
    ItemTpl_1.ItemTpl.KEY_RBOB,
    ItemTpl_1.ItemTpl.KEY_RBORB1,
    ItemTpl_1.ItemTpl.KEY_RBORB2,
    ItemTpl_1.ItemTpl.KEY_RBORB3,
    ItemTpl_1.ItemTpl.KEY_RBSMP,
    ItemTpl_1.ItemTpl.KEY_RBST,
    //Lighthouse
    ItemTpl_1.ItemTpl.KEY_OPERATING_ROOM,
    ItemTpl_1.ItemTpl.KEY_RADAR_STATION_COMMANDANT_ROOM,
    ItemTpl_1.ItemTpl.KEY_ROGUE_USEC_BARRACK,
    ItemTpl_1.ItemTpl.KEY_WATER_TREATMENT_PLANT_STORAGE_ROOM,
    //Streets
    ItemTpl_1.ItemTpl.KEY_ABANDONED_FACTORY_MARKED,
    ItemTpl_1.ItemTpl.KEY_BACKUP_HIDEOUT,
    ItemTpl_1.ItemTpl.KEY_BELUGA_RESTAURANT_DIRECTOR,
    ItemTpl_1.ItemTpl.KEY_CAR_DEALERSHIP_CLOSED_SECTION,
    ItemTpl_1.ItemTpl.KEY_CAR_DEALERSHIP_DIRECTORS_OFFICE_ROOM,
    ItemTpl_1.ItemTpl.KEY_CHEKANNAYA_15_APARTMENT,
    ItemTpl_1.ItemTpl.KEY_CONCORDIA_SECURITY_ROOM,
    ItemTpl_1.ItemTpl.KEY_IRON_GATE,
    ItemTpl_1.ItemTpl.KEY_NEGOTIATION_ROOM,
    ItemTpl_1.ItemTpl.KEY_PINEWOOD_HOTEL_ROOM_215,
    //ItemTpl.KEY_PRIMORSKY_4648_SKYBRIDGE,
    ItemTpl_1.ItemTpl.KEY_REAL_ESTATE_AGENCY_OFFICE_ROOM,
    ItemTpl_1.ItemTpl.KEY_RELAXATION_ROOM,
    // ItemTpl.KEY_RUSTED_BLOODY, // haha
    ItemTpl_1.ItemTpl.KEY_TERRAGROUP_MEETING_ROOM,
    ItemTpl_1.ItemTpl.KEY_XRAY_ROOM,
    //GroundZero
    ItemTpl_1.ItemTpl.KEY_TERRAGROUP_SCIENCE_OFFICE,
    //Others
    ItemTpl_1.ItemTpl.KEY_MISSAM_FORKLIFT,
];
exports.markedKeys = [
    ItemTpl_1.ItemTpl.KEY_DORM_ROOM_314_MARKED,
    ItemTpl_1.ItemTpl.KEY_RBBK_MARKED,
    ItemTpl_1.ItemTpl.KEY_RBVO_MARKED,
    ItemTpl_1.ItemTpl.KEY_SHARED_BEDROOM_MARKED,
    ItemTpl_1.ItemTpl.KEY_RBPKPM_MARKED,
    ItemTpl_1.ItemTpl.KEY_MYSTERIOUS_ROOM_MARKED,
    ItemTpl_1.ItemTpl.KEY_ABANDONED_FACTORY_MARKED,
];
//# sourceMappingURL=keys.js.map