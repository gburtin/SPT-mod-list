"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrefixLogger = void 0;
class PrefixLogger {
    static instance = null;
    logger;
    prefix;
    debug;
    // Private constructor prevents direct instantiation
    constructor(logger, prefix, debug) {
        this.logger = logger;
        this.prefix = prefix;
        this.debug = debug;
    }
    // Singleton initializer
    static getInstance(container, debug = false) {
        if (!PrefixLogger.instance) {
            if (!container) {
                throw new Error("PrefixLogger: Container not provided");
            }
            const logger = container.resolve("WinstonLogger");
            PrefixLogger.instance = new PrefixLogger(logger, "[Softcore]", debug);
        }
        return PrefixLogger.instance;
    }
    setDebug(debug) {
        this.debug = debug;
    }
    info(message) {
        this.logger.info(`${this.prefix} ${message}`);
    }
    warning(message) {
        this.logger.warning(`${this.prefix} ${message}`);
    }
    error(message) {
        this.logger.error(`${this.prefix} ${message}`);
    }
    debugLog(message) {
        if (this.debug) {
            this.logger.info(`${this.prefix} [DEBUG] ${message}`);
        }
    }
}
exports.PrefixLogger = PrefixLogger;
//# sourceMappingURL=PrefixLogger.js.map